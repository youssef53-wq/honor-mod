package com.honor.honormod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public final class ModItems {
	private ModItems() {}

	public static Item HONOR_STATUS;

	public static void register() {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM,
			Identifier.fromNamespaceAndPath(HonorMod.MOD_ID, "honor_status"));
		HONOR_STATUS = Registry.register(BuiltInRegistries.ITEM, key,
			new HonorStatusItem(new Item.Properties().setId(key).stacksTo(1)));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
			.register(entries -> entries.accept(HONOR_STATUS));
	}
}
