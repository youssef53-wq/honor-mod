# Honor System (Fabric, Minecraft Java 26.3)

An RDR2-inspired Honor system. Red skull icon = honor lost, white Steve icon = honor gained.

## Build
1. Install JDK 25 and Gradle 9.5+ (or run `gradle wrapper` once to create ./gradlew).
2. In this folder run: `gradle build`
3. The mod is `build/libs/honor-1.0.0.jar`. Put it, plus Fabric API for 26.3, in `.minecraft/mods`.

## Targeting another version
Edit `gradle.properties` (`minecraft_version`, `fabric_version`, `loader_version`, `loom_version`).
Values for each version are listed at https://fabricmc.net/develop

## Use
- Honor Status item: craftable (paper + gold nugget), in the Creative Tools tab, and given once on first join. Right-click to open.
- The Honor Status screen also holds the HUD settings (position, size, toggles).
- Commands: `/honor`, `/honor set|add|remove <player> <n>`, `/honor reset <player>` (ops only).
- Config: `config/honor-server.json` (all honor values, villager and anti-exploit settings) and `config/honor-client.json`.
- Honor is saved per player in `<world>/honor/<uuid>.json`.
