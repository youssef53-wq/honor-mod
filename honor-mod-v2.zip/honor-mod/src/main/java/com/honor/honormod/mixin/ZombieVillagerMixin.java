package com.honor.honormod.mixin;

import com.honor.honormod.HonorEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.zombie.ZombieVillager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;

@Mixin(ZombieVillager.class)
public abstract class ZombieVillagerMixin {
	@Shadow
	private UUID conversionStarter;

	@Inject(method = "finishConversion", at = @At("HEAD"))
	private void honor$cured(ServerLevel level, CallbackInfo ci) {
		if (conversionStarter != null) {
			ServerPlayer player = level.getServer().getPlayerList().getPlayer(conversionStarter);
			if (player != null) {
				HonorEvents.onCure(player, ((ZombieVillager) (Object) this).getUUID());
			}
		}
	}
}
