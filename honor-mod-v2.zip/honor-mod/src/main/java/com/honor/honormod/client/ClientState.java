package com.honor.honormod.client;

import java.util.ArrayList;
import java.util.List;

/** The client's copy of the player's honor, synced from the server. */
public final class ClientState {
	private ClientState() {}

	public static final class Notice {
		public final int delta;
		public final long start;

		Notice(int delta, long start) {
			this.delta = delta;
			this.start = start;
		}
	}

	public static int honor = 0;
	public static final List<Notice> NOTICES = new ArrayList<>();

	public static void push(int delta) {
		NOTICES.add(new Notice(delta, System.currentTimeMillis()));
		while (NOTICES.size() > 4) {
			NOTICES.remove(0);
		}
	}

	public static void reset() {
		honor = 0;
		NOTICES.clear();
	}
}
