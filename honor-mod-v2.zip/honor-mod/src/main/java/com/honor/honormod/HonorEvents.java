package com.honor.honormod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.sounds.SoundEvents;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Honor gameplay rules: kills, villager help, raids, and villager atmosphere. */
public final class HonorEvents {
	private HonorEvents() {}

	private static final Map<UUID, Boolean> HERO_STATE = new HashMap<>();

	public static void register() {
		ServerLivingEntityEvents.AFTER_DEATH.register(HonorEvents::onDeath);
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			int tick = server.getTickCount();
			if (tick % 20 == 0) {
				for (ServerPlayer p : server.getPlayerList().getPlayers()) {
					checkHero(p);
				}
			}
			if (tick % 60 == 0) {
				for (ServerPlayer p : server.getPlayerList().getPlayers()) {
					villagerAtmosphere(p);
				}
			}
		});
	}

	public static void forget(ServerPlayer player) {
		HERO_STATE.remove(player.getUUID());
	}

	// ------------------------------------------------------------------ kills

	/** Honor value of killing this entity: negative for peaceful, positive for hostile, 0 for none. */
	static int valueFor(LivingEntity entity, HonorConfig cfg) {
		String id = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).toString();
		Integer explicit = cfg.entityValues.get(id);
		if (explicit != null) {
			return explicit;
		}
		MobCategory cat = entity.getType().getCategory();
		return switch (cat) {
			case MONSTER -> cfg.otherHostile;
			case CREATURE -> cfg.passiveAnimal;
			case AMBIENT, WATER_CREATURE, UNDERGROUND_WATER_CREATURE, WATER_AMBIENT, AXOLOTLS -> cfg.otherPeaceful;
			default -> 0;
		};
	}

	private static void onDeath(LivingEntity entity, DamageSource source) {
		HonorConfig cfg = HonorMod.config;
		if (!cfg.enabled || entity instanceof Player || !(entity instanceof Mob mob)) {
			return;
		}
		if (!(entity.level() instanceof ServerLevel level)) {
			return;
		}
		// Only direct player credit: arrows/tridents resolve to their owner via getEntity().
		// Fall damage, lava, suffocation, other mobs, etc. never reach this branch.
		if (!(source.getEntity() instanceof ServerPlayer killer)) {
			return;
		}
		if (cfg.ignoreCreativeModeKills && killer.isCreative()) {
			return;
		}
		// Each death is processed exactly once.
		if (!AntiExploit.firstTime(entity.getUUID())) {
			return;
		}

		int value = valueFor(entity, cfg);
		if (value < 0) {
			if (cfg.peacefulPenalties) {
				HonorManager.add(killer, value);
			}
			return;
		}
		if (value == 0) {
			return;
		}

		int total = 0;
		if (cfg.hostileRewards) {
			long chunk = (((long) (entity.blockPosition().getX() >> 4)) << 32)
				^ ((entity.blockPosition().getZ() >> 4) & 0xFFFFFFFFL);
			total += AntiExploit.limitHostileGain(killer.getUUID(), value, chunk, cfg);
		}

		if (cfg.villagerHelpRewards && mob.getType().getCategory() == MobCategory.MONSTER) {
			long coolSave = 10_000L;
			long coolProtect = cfg.protectCooldownSeconds * 1000L;
			if (mob.getTarget() instanceof Villager
				&& AntiExploit.tryCooldown("save:" + killer.getUUID(), coolSave)) {
				total += cfg.savingVillagers;
			}
			List<Villager> near = level.getEntitiesOfClass(Villager.class, entity.getBoundingBox().inflate(12.0));
			if (!near.isEmpty() && AntiExploit.tryCooldown("protect:" + killer.getUUID(), coolProtect)) {
				total += cfg.protectingVillagers;
			}
		}

		if (total != 0) {
			HonorManager.add(killer, total);
		}
	}

	// ------------------------------------------------------------ villager help

	public static void onTrade(Villager villager, ServerPlayer player) {
		HonorConfig cfg = HonorMod.config;
		if (!cfg.enabled || !cfg.villagerHelpRewards) {
			return;
		}
		String key = "trade:" + player.getUUID() + ":" + villager.getUUID();
		if (AntiExploit.tryCooldown(key, cfg.tradeHonorCooldownSeconds * 1000L)) {
			HonorManager.add(player, cfg.trading);
		}
	}

	public static void onCure(ServerPlayer player, UUID zombieVillagerId) {
		HonorConfig cfg = HonorMod.config;
		if (!cfg.enabled || !cfg.villagerHelpRewards) {
			return;
		}
		if (AntiExploit.firstTime(zombieVillagerId)) {
			HonorManager.add(player, cfg.cureZombieVillager);
		}
	}

	/** Hero of the Village is granted by vanilla when a raid is won: that is our "defended the village" signal. */
	private static void checkHero(ServerPlayer player) {
		HonorConfig cfg = HonorMod.config;
		boolean has = player.hasEffect(MobEffects.HERO_OF_THE_VILLAGE);
		Boolean before = HERO_STATE.put(player.getUUID(), has);
		if (before != null && !before && has && cfg.enabled && cfg.villagerHelpRewards) {
			HonorManager.add(player, cfg.defendingRaid);
		}
	}

	// ----------------------------------------------------------- atmosphere

	private static void villagerAtmosphere(ServerPlayer player) {
		HonorConfig cfg = HonorMod.config;
		if (!cfg.enabled || !cfg.villagerReactions || !(player.level() instanceof ServerLevel level)) {
			return;
		}
		int honor = HonorManager.get(player);
		boolean high = honor >= cfg.highHonorThreshold;
		boolean low = honor <= cfg.lowHonorThreshold;
		if (!high && !low) {
			return;
		}
		for (Villager v : level.getEntitiesOfClass(Villager.class, player.getBoundingBox().inflate(8.0))) {
			if (level.getRandom().nextInt(4) != 0) {
				continue;
			}
			if (cfg.villagerParticles) {
				level.sendParticles(high ? ParticleTypes.HAPPY_VILLAGER : ParticleTypes.ANGRY_VILLAGER,
					v.getX(), v.getY() + 1.9, v.getZ(), 2, 0.3, 0.2, 0.3, 0.0);
			}
			if (cfg.villagerSounds && level.getRandom().nextInt(3) == 0) {
				v.playSound(high ? SoundEvents.VILLAGER_YES : SoundEvents.VILLAGER_NO, 1.0F, 1.0F);
			}
		}
	}
}
