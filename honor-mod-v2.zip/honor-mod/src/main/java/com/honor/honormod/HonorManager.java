package com.honor.honormod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Server-side honor storage. One small JSON file per player UUID inside the world folder
 * (world/honor/UUID.json), so honor survives death, relogging and server restarts.
 */
public final class HonorManager {
	public static final int MIN = -100;
	public static final int MAX = 100;
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	public static class PlayerData {
		public int honor = 0;
		public boolean receivedItem = false;
	}

	private static MinecraftServer server;
	private static final Map<UUID, PlayerData> CACHE = new HashMap<>();

	private HonorManager() {}

	public static void setServer(MinecraftServer s) {
		server = s;
	}

	private static Path dir() {
		return server.getWorldPath(LevelResource.ROOT).resolve("honor");
	}

	public static PlayerData data(ServerPlayer player) {
		return CACHE.computeIfAbsent(player.getUUID(), id -> read(id));
	}

	private static PlayerData read(UUID id) {
		try {
			Path file = dir().resolve(id + ".json");
			if (Files.exists(file)) {
				PlayerData d = GSON.fromJson(Files.readString(file), PlayerData.class);
				if (d != null) {
					d.honor = Math.max(MIN, Math.min(MAX, d.honor));
					return d;
				}
			}
		} catch (Exception e) {
			HonorMod.LOGGER.error("Could not read honor data for {}", id, e);
		}
		return new PlayerData();
	}

	private static void write(UUID id, PlayerData d) {
		try {
			Files.createDirectories(dir());
			Files.writeString(dir().resolve(id + ".json"), GSON.toJson(d));
		} catch (IOException e) {
			HonorMod.LOGGER.error("Could not save honor data for {}", id, e);
		}
	}

	public static int get(ServerPlayer player) {
		return data(player).honor;
	}

	/** Changes honor by delta (clamped). Returns the delta that was actually applied. */
	public static int add(ServerPlayer player, int delta) {
		return set(player, get(player) + delta);
	}

	/** Sets honor (clamped) and notifies the client. Returns the actual change. */
	public static int set(ServerPlayer player, int value) {
		PlayerData d = data(player);
		int clamped = Math.max(MIN, Math.min(MAX, value));
		int applied = clamped - d.honor;
		d.honor = clamped;
		write(player.getUUID(), d);
		if (applied != 0) {
			sync(player, applied);
		}
		return applied;
	}

	public static void sync(ServerPlayer player, int delta) {
		if (ServerPlayNetworking.canSend(player, HonorSyncPayload.TYPE)) {
			ServerPlayNetworking.send(player, new HonorSyncPayload(get(player), delta));
		}
	}

	public static void onJoin(ServerPlayer player) {
		data(player); // loads from disk
		sync(player, 0);
	}

	public static void save(ServerPlayer player) {
		write(player.getUUID(), data(player));
	}

	public static void onLeave(ServerPlayer player) {
		PlayerData d = CACHE.remove(player.getUUID());
		if (d != null) {
			write(player.getUUID(), d);
		}
	}

	public static void saveAll() {
		for (Map.Entry<UUID, PlayerData> e : CACHE.entrySet()) {
			write(e.getKey(), e.getValue());
		}
	}

	public static void clear() {
		CACHE.clear();
		server = null;
	}
}
