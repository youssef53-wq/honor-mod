package com.honor.honormod.client;

import com.honor.honormod.HonorMod;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

import java.util.Iterator;

/** Draws the honor icon beside the hotbar and the sliding notifications. */
public final class HonorHud {
	private HonorHud() {}

	public static final Identifier ICON_LOW = Identifier.fromNamespaceAndPath(HonorMod.MOD_ID, "textures/gui/icon_low.png");
	public static final Identifier ICON_HIGH = Identifier.fromNamespaceAndPath(HonorMod.MOD_ID, "textures/gui/icon_high.png");

	public static final int COLOR_POSITIVE = 0xFFF2F2F2;
	public static final int COLOR_NEGATIVE = 0xFFE0243A;

	public static void drawIcon(GuiGraphicsExtractor g, int honor, int x, int y, int size) {
		Identifier tex = honor < 0 ? ICON_LOW : ICON_HIGH;
		g.blit(RenderPipelines.GUI_TEXTURED, tex, x, y, 0f, 0f, size, size, 48, 48, 48, 48);
	}

	public static void render(GuiGraphicsExtractor g, DeltaTracker tracker) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null) {
			return;
		}
		ClientConfig cfg = ClientConfig.INSTANCE;
		int w = mc.getWindow().getGuiScaledWidth();
		int h = mc.getWindow().getGuiScaledHeight();

		if (cfg.hudEnabled) {
			int size = Math.max(8, cfg.hudSize);
			int x = w / 2 - 91 - 32 - size + cfg.hudOffsetX;
			int y = h - size - 2 + cfg.hudOffsetY;
			drawIcon(g, ClientState.honor, x, y, size);
			if (cfg.showHudValue) {
				String s = (ClientState.honor > 0 ? "+" : "") + ClientState.honor;
				int color = ClientState.honor < 0 ? COLOR_NEGATIVE : COLOR_POSITIVE;
				g.text(mc.font, s, x + (size - mc.font.width(s)) / 2, y - 10, color, true);
			}
		}

		if (cfg.notificationsEnabled) {
			renderNotices(g, mc, w, cfg);
		}
	}

	private static void renderNotices(GuiGraphicsExtractor g, Minecraft mc, int screenW, ClientConfig cfg) {
		long now = System.currentTimeMillis();
		long life = Math.max(1000L, cfg.notificationSeconds * 1000L);
		int boxW = 132;
		int boxH = 28;
		int slot = 0;
		Iterator<ClientState.Notice> it = ClientState.NOTICES.iterator();
		while (it.hasNext()) {
			ClientState.Notice n = it.next();
			long t = now - n.start;
			if (t > life) {
				it.remove();
				continue;
			}
			double p = 1.0;
			if (t < 250) {
				p = t / 250.0;
			} else if (t > life - 300) {
				p = (life - t) / 300.0;
			}
			p = 1.0 - Math.pow(1.0 - Math.max(0, Math.min(1, p)), 3); // ease-out
			boolean positive = n.delta > 0;
			int baseX = screenW - boxW - 8 + cfg.notificationOffsetX;
			int x = baseX + (int) ((1.0 - p) * (boxW + 16));
			int y = 8 + slot * (boxH + 4) + cfg.notificationOffsetY;
			int accent = positive ? COLOR_POSITIVE : COLOR_NEGATIVE;

			g.fill(x, y, x + boxW, y + boxH, 0xD8101010);
			g.fill(x, y, x + 3, y + boxH, accent);
			drawIcon(g, positive ? 1 : -1, x + 8, y + 3, 22);
			String title = positive ? "Honor Increased" : "Honor Decreased";
			String amount = (positive ? "+" : "") + n.delta;
			g.text(mc.font, title, x + 36, y + 6, accent, true);
			g.text(mc.font, amount, x + 36, y + 16, accent, true);
			slot++;
		}
	}
}
