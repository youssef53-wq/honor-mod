package com.honor.honormod;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class HonorStatusItem extends Item {
	public HonorStatusItem(Item.Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (level.isClientSide()) {
			HonorMod.clientOpenScreen.run();
		}
		return InteractionResult.SUCCESS;
	}
}
