package com.honor.honormod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** Server-side configuration, stored at config/honor-server.json. Every value is editable. */
public class HonorConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("honor-server.json");

	// ---- feature toggles ----
	public boolean enabled = true;
	public boolean peacefulPenalties = true;
	public boolean hostileRewards = true;
	public boolean villagerHelpRewards = true;
	public boolean villagerReactions = true;
	public boolean tradingModifiers = true;
	public boolean giveItemOnFirstJoin = true;
	public boolean ignoreCreativeModeKills = false;

	// ---- kill values by entity id (checked first) ----
	public Map<String, Integer> entityValues = new LinkedHashMap<>();
	// ---- kill fallbacks ----
	public int passiveAnimal = -3;
	public int otherPeaceful = -3;
	public int otherHostile = 3;

	// ---- helping villagers ----
	public int trading = 2;
	public int cureZombieVillager = 15;
	public int protectingVillagers = 5;
	public int defendingRaid = 10;
	public int savingVillagers = 3;

	// ---- villager reactions ----
	public int highHonorThreshold = 25;
	public int lowHonorThreshold = -25;
	/** Max price change at +/-100 honor (0.25 = 25 percent). */
	public double maxPriceModifier = 0.25;
	public boolean villagerParticles = true;
	public boolean villagerSounds = true;

	// ---- anti-exploit ----
	public int hostileGainWindowSeconds = 600;
	public int hostileGainMaxPerWindow = 20;
	public int sameChunkKillsPerWindow = 12;
	public int tradeHonorCooldownSeconds = 300;
	public int protectCooldownSeconds = 30;

	public HonorConfig() {
		entityValues.put("minecraft:villager", -10);
		entityValues.put("minecraft:wandering_trader", -10);
		entityValues.put("minecraft:iron_golem", -15);
		entityValues.put("minecraft:cat", -10);
		entityValues.put("minecraft:wolf", -10);
		entityValues.put("minecraft:horse", -10);
		entityValues.put("minecraft:donkey", -10);
		entityValues.put("minecraft:mule", -10);
		entityValues.put("minecraft:zombie", 3);
		entityValues.put("minecraft:skeleton", 3);
		entityValues.put("minecraft:creeper", 4);
		entityValues.put("minecraft:spider", 2);
		entityValues.put("minecraft:cave_spider", 2);
		entityValues.put("minecraft:witch", 5);
		entityValues.put("minecraft:pillager", 5);
		entityValues.put("minecraft:zombie_horse", 0);
		entityValues.put("minecraft:skeleton_horse", 0);
	}

	public static HonorConfig load() {
		HonorConfig cfg = new HonorConfig();
		try {
			if (Files.exists(FILE)) {
				HonorConfig read = GSON.fromJson(Files.readString(FILE), HonorConfig.class);
				if (read != null) {
					cfg = read;
				}
			}
			cfg.save(); // writes defaults / adds new fields
		} catch (Exception e) {
			HonorMod.LOGGER.error("Could not read honor-server.json, using defaults", e);
		}
		return cfg;
	}

	public void save() {
		try {
			Files.createDirectories(FILE.getParent());
			Files.writeString(FILE, GSON.toJson(this));
		} catch (IOException e) {
			HonorMod.LOGGER.error("Could not write honor-server.json", e);
		}
	}
}
