package com.honor.honormod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Server to client: current honor, plus the change that caused the update (0 = silent sync). */
public record HonorSyncPayload(int honor, int delta) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<HonorSyncPayload> TYPE =
		new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(HonorMod.MOD_ID, "sync"));

	public static final StreamCodec<RegistryFriendlyByteBuf, HonorSyncPayload> CODEC = StreamCodec.composite(
		ByteBufCodecs.VAR_INT, HonorSyncPayload::honor,
		ByteBufCodecs.VAR_INT, HonorSyncPayload::delta,
		HonorSyncPayload::new
	);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
