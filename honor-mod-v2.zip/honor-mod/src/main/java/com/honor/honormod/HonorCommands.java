package com.honor.honormod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class HonorCommands {
	private HonorCommands() {}

	private static String describe(int honor) {
		return (honor > 0 ? "+" : "") + honor + " (" + HonorLevel.of(honor).displayName + ")";
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, selection) -> {
			LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("honor")
				.executes(ctx -> {
					ServerPlayer p = ctx.getSource().getPlayerOrException();
					ctx.getSource().sendSuccess(() -> Component.literal("Your honor: " + describe(HonorManager.get(p))), false);
					return 1;
				});

			root.then(Commands.literal("set").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
				.then(Commands.argument("target", EntityArgument.player())
					.then(Commands.argument("value", IntegerArgumentType.integer(HonorManager.MIN, HonorManager.MAX))
						.executes(ctx -> {
							ServerPlayer t = EntityArgument.getPlayer(ctx, "target");
							HonorManager.set(t, IntegerArgumentType.getInteger(ctx, "value"));
							ctx.getSource().sendSuccess(() -> Component.literal(t.getName().getString() + " honor is now " + describe(HonorManager.get(t))), true);
							return 1;
						}))));

			root.then(Commands.literal("add").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
				.then(Commands.argument("target", EntityArgument.player())
					.then(Commands.argument("amount", IntegerArgumentType.integer(-200, 200))
						.executes(ctx -> {
							ServerPlayer t = EntityArgument.getPlayer(ctx, "target");
							HonorManager.add(t, IntegerArgumentType.getInteger(ctx, "amount"));
							ctx.getSource().sendSuccess(() -> Component.literal(t.getName().getString() + " honor is now " + describe(HonorManager.get(t))), true);
							return 1;
						}))));

			root.then(Commands.literal("remove").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
				.then(Commands.argument("target", EntityArgument.player())
					.then(Commands.argument("amount", IntegerArgumentType.integer(0, 200))
						.executes(ctx -> {
							ServerPlayer t = EntityArgument.getPlayer(ctx, "target");
							HonorManager.add(t, -IntegerArgumentType.getInteger(ctx, "amount"));
							ctx.getSource().sendSuccess(() -> Component.literal(t.getName().getString() + " honor is now " + describe(HonorManager.get(t))), true);
							return 1;
						}))));

			root.then(Commands.literal("reset").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
				.then(Commands.argument("target", EntityArgument.player())
					.executes(ctx -> {
						ServerPlayer t = EntityArgument.getPlayer(ctx, "target");
						HonorManager.set(t, 0);
						ctx.getSource().sendSuccess(() -> Component.literal(t.getName().getString() + " honor reset to 0"), true);
						return 1;
					})));

			dispatcher.register(root);
		});
	}
}
