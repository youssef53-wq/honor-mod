package com.honor.honormod.client;

import com.honor.honormod.HonorLevel;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** The screen opened by the Honor Status item: honor, level, bar, description and HUD settings. */
public class HonorStatusScreen extends Screen {
	private static final int PANEL_W = 240;
	private static final int PANEL_H = 148;

	private int left;
	private int top;
	private Button hudButton;
	private Button notifButton;
	private Button soundButton;

	public HonorStatusScreen() {
		super(Component.literal("Honor Status"));
	}

	private static Component onOff(String label, boolean on) {
		return Component.literal(label + ": " + (on ? "ON" : "OFF"));
	}

	@Override
	protected void init() {
		left = (this.width - PANEL_W) / 2;
		top = (this.height - 232) / 2;
		ClientConfig c = ClientConfig.INSTANCE;
		int y1 = top + 168;
		int y2 = y1 + 24;
		int y3 = y2 + 24;

		hudButton = Button.builder(onOff("HUD Icon", c.hudEnabled), b -> {
			c.hudEnabled = !c.hudEnabled;
			b.setMessage(onOff("HUD Icon", c.hudEnabled));
			c.save();
		}).bounds(left, y1, 118, 20).build();
		notifButton = Button.builder(onOff("Notices", c.notificationsEnabled), b -> {
			c.notificationsEnabled = !c.notificationsEnabled;
			b.setMessage(onOff("Notices", c.notificationsEnabled));
			c.save();
		}).bounds(left + 122, y1, 118, 20).build();
		soundButton = Button.builder(onOff("Sounds", c.soundsEnabled), b -> {
			c.soundsEnabled = !c.soundsEnabled;
			b.setMessage(onOff("Sounds", c.soundsEnabled));
			c.save();
		}).bounds(left, y2, 118, 20).build();
		Button reset = Button.builder(Component.literal("Reset HUD"), b -> {
			c.hudOffsetX = 0;
			c.hudOffsetY = 0;
			c.hudSize = 24;
			c.save();
		}).bounds(left + 122, y2, 118, 20).build();

		Button l = Button.builder(Component.literal("<"), b -> move(-4, 0)).bounds(left, y3, 24, 20).build();
		Button r = Button.builder(Component.literal(">"), b -> move(4, 0)).bounds(left + 28, y3, 24, 20).build();
		Button u = Button.builder(Component.literal("^"), b -> move(0, -4)).bounds(left + 56, y3, 24, 20).build();
		Button d = Button.builder(Component.literal("v"), b -> move(0, 4)).bounds(left + 84, y3, 24, 20).build();
		Button smaller = Button.builder(Component.literal("Size -"), b -> resize(-4)).bounds(left + 122, y3, 58, 20).build();
		Button bigger = Button.builder(Component.literal("Size +"), b -> resize(4)).bounds(left + 182, y3, 58, 20).build();

		for (Button b : new Button[] {hudButton, notifButton, soundButton, reset, l, r, u, d, smaller, bigger}) {
			addRenderableWidget(b);
		}
	}

	private void move(int dx, int dy) {
		ClientConfig c = ClientConfig.INSTANCE;
		c.hudOffsetX += dx;
		c.hudOffsetY += dy;
		c.save();
	}

	private void resize(int delta) {
		ClientConfig c = ClientConfig.INSTANCE;
		c.hudSize = Math.max(12, Math.min(64, c.hudSize + delta));
		c.save();
	}

	private void centered(GuiGraphicsExtractor g, String s, int y, int color) {
		g.text(this.font, s, left + (PANEL_W - this.font.width(s)) / 2, y, color, true);
	}

	private List<String> wrap(String text, int maxWidth) {
		List<String> lines = new ArrayList<>();
		StringBuilder line = new StringBuilder();
		for (String word : text.split(" ")) {
			String test = line.isEmpty() ? word : line + " " + word;
			if (this.font.width(test) > maxWidth && !line.isEmpty()) {
				lines.add(line.toString());
				line = new StringBuilder(word);
			} else {
				line = new StringBuilder(test);
			}
		}
		if (!line.isEmpty()) {
			lines.add(line.toString());
		}
		return lines;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
		super.extractRenderState(g, mouseX, mouseY, partialTick); // background + buttons (below the panel area)

		int honor = ClientState.honor;
		HonorLevel level = HonorLevel.of(honor);
		int accent = honor < 0 ? HonorHud.COLOR_NEGATIVE : HonorHud.COLOR_POSITIVE;

		// Panel (the buttons live below it, so nothing is covered)
		g.fill(left - 4, top, left + PANEL_W + 4, top + PANEL_H + 12, 0xE0101010);
		g.outline(left - 4, top, PANEL_W + 8, PANEL_H + 12, accent);

		centered(g, "HONOR", top + 8, 0xFFAAAAAA);
		HonorHud.drawIcon(g, honor, left + (PANEL_W - 40) / 2, top + 20, 40);
		centered(g, level.displayName, top + 66, accent);

		// Honor bar: grows right (white) for good honor, left (red) for bad honor
		int barX = left + 10;
		int barW = PANEL_W - 20;
		int barY = top + 82;
		int mid = barX + barW / 2;
		g.fill(barX, barY, barX + barW, barY + 8, 0xFF1C1C1C);
		int len = (int) Math.round(Math.abs(honor) / 100.0 * (barW / 2.0));
		if (honor >= 0) {
			g.fill(mid, barY, mid + len, barY + 8, HonorHud.COLOR_POSITIVE);
		} else {
			g.fill(mid - len, barY, mid, barY + 8, HonorHud.COLOR_NEGATIVE);
		}
		g.fill(mid - 1, barY - 2, mid + 1, barY + 10, 0xFF888888);
		g.outline(barX - 1, barY - 1, barW + 2, 10, 0xFF555555);

		centered(g, "Honor: " + (honor > 0 ? "+" : "") + honor + " / 100", top + 96, 0xFFFFFFFF);

		int y = top + 110;
		for (String line : wrap(level.description, PANEL_W - 16)) {
			centered(g, line, y, 0xFFBBBBBB);
			y += 11;
		}
		centered(g, "HUD settings", top + PANEL_H + 14, 0xFF888888);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
