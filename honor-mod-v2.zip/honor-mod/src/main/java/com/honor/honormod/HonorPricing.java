package com.honor.honormod;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.trading.MerchantOffer;

/** Adjusts vanilla villager trade prices using the vanilla "special price diff" system. */
public final class HonorPricing {
	private HonorPricing() {}

	public static void apply(Villager villager, ServerPlayer player) {
		HonorConfig cfg = HonorMod.config;
		if (!cfg.enabled || !cfg.tradingModifiers || !cfg.villagerReactions) {
			return;
		}
		int honor = HonorManager.get(player);
		boolean high = honor >= cfg.highHonorThreshold;
		boolean low = honor <= cfg.lowHonorThreshold;
		if (!high && !low) {
			return;
		}
		double factor = cfg.maxPriceModifier * Math.abs(honor) / 100.0;
		for (MerchantOffer offer : villager.getOffers()) {
			int base = offer.getBaseCostA().getCount();
			int amount = (int) Math.max(1, Math.round(base * factor));
			offer.addToSpecialPriceDiff(high ? -amount : amount);
		}
	}
}
