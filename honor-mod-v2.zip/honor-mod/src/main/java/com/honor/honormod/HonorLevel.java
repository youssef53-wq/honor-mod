package com.honor.honormod;

/** Named honor tiers and their descriptions. */
public enum HonorLevel {
	NOTORIOUS(-100, "Notorious", "Feared and despised. Villagers flee your shadow."),
	DISHONORABLE(-80, "Dishonorable", "A known scoundrel. Villagers overcharge and keep their distance."),
	QUESTIONABLE(-40, "Questionable", "People whisper about you. Villagers are wary."),
	NEUTRAL(-15, "Neutral", "Nobody knows quite what to make of you."),
	RESPECTED(15, "Respected", "Folk speak well of you. Villagers are friendlier."),
	HONORABLE(40, "Honorable", "A trusted hand. Villagers offer fair prices."),
	EXEMPLARY(80, "Exemplary", "A true hero. Villagers welcome you with open arms.");

	public final int min;
	public final String displayName;
	public final String description;

	HonorLevel(int min, String displayName, String description) {
		this.min = min;
		this.displayName = displayName;
		this.description = description;
	}

	public static HonorLevel of(int honor) {
		HonorLevel result = NOTORIOUS;
		for (HonorLevel level : values()) {
			if (honor >= level.min) {
				result = level;
			}
		}
		return result;
	}
}
