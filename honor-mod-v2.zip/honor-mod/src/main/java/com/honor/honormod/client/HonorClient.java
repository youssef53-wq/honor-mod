package com.honor.honormod.client;

import com.honor.honormod.HonorMod;
import com.honor.honormod.HonorSyncPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;

public class HonorClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ClientConfig.load();

		HudElementRegistry.attachElementAfter(VanillaHudElements.HOTBAR,
			Identifier.fromNamespaceAndPath(HonorMod.MOD_ID, "honor_hud"), HonorHud::render);

		ClientPlayNetworking.registerGlobalReceiver(HonorSyncPayload.TYPE, (payload, context) -> {
			ClientState.honor = payload.honor();
			if (payload.delta() != 0) {
				ClientState.push(payload.delta());
				if (ClientConfig.INSTANCE.soundsEnabled) {
					Minecraft mc = Minecraft.getInstance();
					if (payload.delta() > 0) {
						mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.2F, 0.8F));
					} else {
						mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.VILLAGER_NO, 0.8F, 0.8F));
					}
				}
			}
		});

		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientState.reset());

		HonorMod.clientOpenScreen = () -> Minecraft.getInstance().setScreenAndShow(new HonorStatusScreen());
	}
}
