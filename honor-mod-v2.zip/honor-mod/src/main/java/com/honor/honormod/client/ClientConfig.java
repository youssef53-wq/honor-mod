package com.honor.honormod.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.honor.honormod.HonorMod;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Client settings, stored at config/honor-client.json. Editable in the Honor Status screen. */
public class ClientConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("honor-client.json");
	public static ClientConfig INSTANCE = new ClientConfig();

	public boolean hudEnabled = true;
	public boolean showHudValue = true;
	/** Offset in GUI pixels from the default spot (left of the hotbar). */
	public int hudOffsetX = 0;
	public int hudOffsetY = 0;
	public int hudSize = 24;

	public boolean notificationsEnabled = true;
	public int notificationSeconds = 3;
	public int notificationOffsetX = 0;
	public int notificationOffsetY = 0;

	public boolean soundsEnabled = true;

	public static void load() {
		try {
			if (Files.exists(FILE)) {
				ClientConfig c = GSON.fromJson(Files.readString(FILE), ClientConfig.class);
				if (c != null) {
					INSTANCE = c;
				}
			}
			INSTANCE.save();
		} catch (Exception e) {
			HonorMod.LOGGER.error("Could not read honor-client.json", e);
		}
	}

	public void save() {
		try {
			Files.createDirectories(FILE.getParent());
			Files.writeString(FILE, GSON.toJson(this));
		} catch (Exception e) {
			HonorMod.LOGGER.error("Could not write honor-client.json", e);
		}
	}
}
