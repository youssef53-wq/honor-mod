package com.honor.honormod.mixin;

import com.honor.honormod.HonorEvents;
import com.honor.honormod.HonorPricing;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.trading.MerchantOffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Villager.class)
public abstract class VillagerMixin {
	/** Vanilla applies reputation discounts here; we add honor-based modifiers after it. */
	@Inject(method = "updateSpecialPrices", at = @At("TAIL"))
	private void honor$prices(Player player, CallbackInfo ci) {
		if (player instanceof ServerPlayer sp) {
			HonorPricing.apply((Villager) (Object) this, sp);
		}
	}

	/** Called when a trade is completed. */
	@Inject(method = "notifyTrade", at = @At("TAIL"))
	private void honor$trade(MerchantOffer offer, CallbackInfo ci) {
		Villager self = (Villager) (Object) this;
		if (self.getTradingPlayer() instanceof ServerPlayer sp) {
			HonorEvents.onTrade(self, sp);
		}
	}
}
