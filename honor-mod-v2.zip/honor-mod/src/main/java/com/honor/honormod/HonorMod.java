package com.honor.honormod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.world.item.ItemStack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HonorMod implements ModInitializer {
	public static final String MOD_ID = "honor";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static HonorConfig config = new HonorConfig();
	/** Set by the client entrypoint; the Honor Status item calls it on the logical client. */
	public static Runnable clientOpenScreen = () -> {};

	@Override
	public void onInitialize() {
		config = HonorConfig.load();
		PayloadTypeRegistry.clientboundPlay().register(HonorSyncPayload.TYPE, HonorSyncPayload.CODEC);
		ModItems.register();
		HonorEvents.register();
		HonorCommands.register();

		ServerLifecycleEvents.SERVER_STARTING.register(server -> {
			config = HonorConfig.load();
			HonorManager.setServer(server);
		});
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> HonorManager.saveAll());
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			HonorManager.clear();
			AntiExploit.clear();
		});

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			var player = handler.getPlayer();
			HonorManager.onJoin(player);
			HonorManager.PlayerData d = HonorManager.data(player);
			if (config.giveItemOnFirstJoin && !d.receivedItem) {
				d.receivedItem = true;
				player.getInventory().add(new ItemStack(ModItems.HONOR_STATUS));
				HonorManager.save(player);
			}
		});
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			HonorManager.onLeave(handler.getPlayer());
			HonorEvents.forget(handler.getPlayer());
		});
	}
}
